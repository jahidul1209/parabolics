import React from 'react';

const fallbackUI = () => {
    return(
        <>
        <h1>Something went wrong :(</h1>
        </>
    )
}
export default fallbackUI;