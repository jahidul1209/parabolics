//Finnhub API for stocks
export const STOCK_API = 'https://finnhub.io/api/v1/';
//Token provided by Finnhub after registration. Please, replace it with your personal token
export const TOKEN = 'c45s88aad3idgi81g04g';

