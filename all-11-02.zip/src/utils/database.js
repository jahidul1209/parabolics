//The endpoint of the Firebase database.  Please, replace it with your endpoint
const DATABASE = 'stock-portfolio-45c87-default-rtdb.firebaseio.com/stocks';

export default DATABASE;