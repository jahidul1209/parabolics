import React from 'react';
import PricingSection from '../Components/Presentational/Pricing';
const Pricing = () => {
    return(
        <>
        <PricingSection isFirst={true}/>
        </>
    )
}
export default Pricing;